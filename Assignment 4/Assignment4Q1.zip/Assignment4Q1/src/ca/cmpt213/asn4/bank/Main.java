package ca.cmpt213.asn4.bank;

public class Main {

    public static void main(String[] args) {
    }
}
