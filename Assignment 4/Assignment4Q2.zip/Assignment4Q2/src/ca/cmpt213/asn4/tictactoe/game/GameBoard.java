package ca.cmpt213.asn4.tictactoe.game;

public class GameBoard {

    public GameBoard(){
        int board [][] = new int[3][3];
    }
}
